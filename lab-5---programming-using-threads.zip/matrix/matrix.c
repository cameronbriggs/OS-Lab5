#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>

#define MAX 3 // You can adjust the size of the matrices

int matA[MAX][MAX];
int matB[MAX][MAX];

int matSumResult[MAX][MAX];
int matDiffResult[MAX][MAX];
int matProductResult[MAX][MAX];

struct ThreadArgs {
    int row;
    int col;
};

void fillMatrix(int matrix[MAX][MAX]) {
    for (int i = 0; i < MAX; i++) {
        for (int j = 0; j < MAX; j++) {
            matrix[i][j] = rand() % 10 + 1;
        }
    }
}

void printMatrix(int matrix[MAX][MAX]) {
    for (int i = 0; i < MAX; i++) {
        for (int j = 0; j < MAX; j++) {
            printf("%5d", matrix[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}

void* computeSum(void* args) {
    struct ThreadArgs* coordinates = (struct ThreadArgs*)args;
    matSumResult[coordinates->row][coordinates->col] =
        matA[coordinates->row][coordinates->col] + matB[coordinates->row][coordinates->col];
    return NULL;
}

void* computeDiff(void* args) {
    struct ThreadArgs* coordinates = (struct ThreadArgs*)args;
    matDiffResult[coordinates->row][coordinates->col] =
        matA[coordinates->row][coordinates->col] - matB[coordinates->row][coordinates->col];
    return NULL;
}

void* computeProduct(void* args) {
    struct ThreadArgs* coordinates = (struct ThreadArgs*)args;
    matProductResult[coordinates->row][coordinates->col] = 0;
    for (int k = 0; k < MAX; k++) {
        matProductResult[coordinates->row][coordinates->col] +=
            matA[coordinates->row][k] * matB[k][coordinates->col];
    }
    return NULL;
}

int main() {
    srand(time(0));

    // 0. Get the matrix size from the command line and assign it to MAX
    // (You can manually set it for now)

    // 1. Fill the matrices (matA and matB) with random values.
    fillMatrix(matA);
    fillMatrix(matB);

    // 2. Print the initial matrices.
    printf("Matrix A:\n");
    printMatrix(matA);
    printf("Matrix B:\n");
    printMatrix(matB);

    // 3. Create pthread_t objects for our threads.
    pthread_t threads[MAX * MAX * 3]; // You'll need threads for each cell of each matrix operation
    int threadCount = 0;

    // 4. Create a thread for each cell of each matrix operation.
    for (int i = 0; i < MAX; i++) {
        for (int j = 0; j < MAX; j++) {
            struct ThreadArgs* args = malloc(sizeof(struct ThreadArgs));
            args->row = i;
            args->col = j;

            // Create thread for addition
            pthread_create(&threads[threadCount++], NULL, computeSum, args);

            // Create thread for subtraction
            pthread_create(&threads[threadCount++], NULL, computeDiff, args);

            // Create thread for multiplication
            pthread_create(&threads[threadCount++], NULL, computeProduct, args);
        }
    }

    // 5. Wait for all threads to finish.
    for (int i = 0; i < threadCount; i++) {
        pthread_join(threads[i], NULL);
    }

    // 6. Print the results.
    printf("Results:\n");
    printf("Sum:\n");
    printMatrix(matSumResult);
    printf("Difference:\n");
    printMatrix(matDiffResult);
    printf("Product:\n");
    printMatrix(matProductResult);

    return 0;
}
